#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sim_bp.h"
#include <iostream>
#include <fstream>
#include <sstream>

/*  argc holds the number of command line arguments
    argv[] holds the commands themselves

    Example:-
    sim bimodal 6 gcc_trace.txt
    argc = 4
    argv[0] = sim
    argv[1] = bimodal
    argv[2] = 6
    ... and so on
*/
// ****************************************************************************************************************************//
#define P_TABLE_SIZE (1 << m) // prediction table size = 2^m
#define C_Table_size (1 << k) // chooser table size = 2^k

unsigned char *prediction_table;
unsigned int prediction, misprediction; 
void initialize_prediction_table(int m) {
    prediction_table = (unsigned char *)malloc(P_TABLE_SIZE * sizeof(unsigned char));
    
    for (int i = 0; i < P_TABLE_SIZE; i++) {
        prediction_table[i] = 2; // 2 in binary is 10
    }
}

//***************************** BIMODAL ************************************************//
void bimodal_func(int m, unsigned long int PC_addr, char actual_outcome) {
    initialize_prediction_table(m);
    prediction = misprediction = 0;
    //step 1
    unsigned long int index = (PC_addr >> 2) & ((1 << m) - 1);
    // step2
    unsigned char pred_val = prediction_table[index];

    char predicted_outcome;
    if (pred_val >= 2) {
        predicted_outcome = 't';  // Predicted taken
    } else 
        predicted_outcome = 'n';  // Predicted not taken

    int success; 
    if (actual_outcome == predicted_outcome) {
        success = 1;
    }
    else
    success = 0;

    //step 3
    if ((actual_outcome == 't') && (pred_val < 3)) prediction_table[index] += 1;
    else if((actual_outcome == 'n') && (pred_val > 0)) prediction_table[index] -= 1;

    // prediction count
	if(success == 1) prediction += 1;
	else misprediction += 1;

}

//*************************************** GSHARE ***************************************************//

bool isNBitLong(unsigned int GHR, int n) {
    // Create a mask with n bits set to 1. For example, if n = 4, mask = 0b1111 = 15.
    unsigned int mask = (1 << n) - 1;

    // Check if GHR fits within n bits by using the mask.
    // If (GHR & ~mask) is 0, GHR is n-bit long.
    return (GHR & ~mask) == 0;
}

void gshare_func(int m,unsigned long int PC_addr, int n, unsigned int globalBranchHistoryreg, char actual_outcome){
    initialize_prediction_table(m);
    prediction = misprediction = 0;
    //
    if(isNBitLong(globalBranchHistoryreg, n) == 0){
        printf("error message");
    }
    else 
    {
        // step 1
        PC_addr = PC_addr & ~3;
        unsigned int upper_n_bits = (PC_addr >> (m-n)) & ((1 << n) - 1);
        unsigned int xor_bhr_upperN = globalBranchHistoryreg ^ upper_n_bits; 
        unsigned int lower_mn_bits = PC_addr & ((1 << (m-n)) - 1);
        unsigned int index =  (xor_bhr_upperN << (m-n)) | lower_mn_bits;
        
        // step 2
        unsigned char pred_val = prediction_table[index];
        char predicted_outcome;
        if (pred_val >= 2) {
            predicted_outcome = 't';  // Predicted taken
        } 
        else 
        predicted_outcome = 'n';  // Predicted not taken
        //
        int success; 
        if (actual_outcome == predicted_outcome) {
        success = 1;
        }
        else
        success = 0;
        // step 3
        if ((actual_outcome == 't') && (pred_val < 3)) prediction_table[index] += 1;
        else if((actual_outcome == 'n') && (pred_val > 0)) prediction_table[index] -= 1;
        
        //step 4
        if (actual_outcome == 't'){
            unsigned int temp = globalBranchHistoryreg >> 1;
            globalBranchHistoryreg = temp | (1 << (n-1));
        }
        else {
            unsigned int temp = globalBranchHistoryreg >> 1;
            unsigned int mask = ~(1 << (n - 1));
            globalBranchHistoryreg = temp & mask;
        }
    // prediction count
	if(success == 1) prediction += 1;
	else misprediction += 1;



    }
}
//****************************************** HYBRID *****************************************************/
unsigned char *chooser_table;

void initialize_chooser_table(int k) {
    chooser_table = (unsigned char *)malloc(C_Table_size * sizeof(unsigned char));
    for (int i = 0; i < C_Table_size; i++) {
        prediction_table[i] = 1; 
    }
}
void hybrid_func(int M2, int M1, int k, int n, unsigned long int PC_addr, unsigned int globalBranchHistoryreg, char actual_outcome) {
    initialize_chooser_table(k);
    initialize_prediction_table(M2);
    initialize_prediction_table(M1);
    prediction = misprediction = 0;
    // STEP 1
    //gshare
        // step 1
        unsigned int PC_minus_2bits = PC_addr & ~3;
        unsigned int upper_n_bits = (PC_minus_2bits >> (M1-n)) & ((1 << n) - 1);
        unsigned int xor_bhr_upperN = globalBranchHistoryreg ^ upper_n_bits; 
        unsigned int lower_mn_bits = PC_minus_2bits & ((1 << (M1-n)) - 1);
        unsigned int index_g =  (xor_bhr_upperN << (M1-n)) | lower_mn_bits;
        
        // step 2
        unsigned char pred_val_g = prediction_table[index_g];
        char predicted_outcome_g;
        if (pred_val_g >= 2) {
            predicted_outcome_g = 't';  // Predicted taken
        } else 
        predicted_outcome_g = 'n';  // Predicted not taken

        // STEP 5 //step 4
        if (actual_outcome == 't'){
            unsigned int temp = globalBranchHistoryreg >> 1;
            globalBranchHistoryreg = temp | (1 << (n-1));
        }
        else {
            unsigned int temp = globalBranchHistoryreg >> 1;
            unsigned int mask = ~(1 << (n - 1));
            globalBranchHistoryreg = temp & mask;
        }

    // bimodal
        //step 1
        unsigned long int index_b = (PC_addr >> 2) & ((1 << M2) - 1);
        // step2
        unsigned char pred_val_b = prediction_table[index_b];
        char predicted_outcome_b;
        if (pred_val_b >= 2) {
            predicted_outcome_b = 't';  // Predicted taken
            } else 
            predicted_outcome_b = 'n';  // Predicted not taken

    // STEP 2
    unsigned long int index_c = (PC_addr >> 2) & ((1 << k) - 1);

    // STEP 3 & 4
    unsigned char chosen_val = chooser_table[index_c];

    char predicted_outcome;
    if (chosen_val >= 2) {
        predicted_outcome = predicted_outcome_g;  
        if ((actual_outcome == 't') && (pred_val_g < 3)) prediction_table[index_g] += 1;
        else if((actual_outcome == 'n') && (pred_val_g > 0)) prediction_table[index_g] -= 1;

    } else {
        predicted_outcome = predicted_outcome_b;
        if ((actual_outcome == 't') && (pred_val_b < 3)) prediction_table[index_b] += 1;
        else if((actual_outcome == 'n') && (pred_val_b > 0)) prediction_table[index_b] -= 1;
    }
    //
    int success; 
    if (actual_outcome == predicted_outcome) {
        success = 1;
    }
    else
    success = 0;

    // STEP 6
    if((actual_outcome == predicted_outcome_g) && (actual_outcome != predicted_outcome_b)){
        if (chosen_val < 3)
        {
            chooser_table[index_c] += 1;
        }
    } 
    else if ((actual_outcome != predicted_outcome_g) && (actual_outcome == predicted_outcome_b))
    {
        if (chosen_val >0)
        {
            chooser_table[index_c] -= 1;
        }
    }
    else{
        ;
    }

    // prediction count
	if(success == 1) prediction += 1;
	else misprediction += 1;

}
// ****************************************************************************************************************************//
int main (int argc, char* argv[])
{
    FILE *FP;               // File handler
    char *trace_file;       // Variable that holds trace file name;
    bp_params params;       // look at sim_bp.h header file for the the definition of struct bp_params
    char outcome;           // Variable holds branch outcome
    unsigned long int addr; // Variable holds the address read from input file
    if (!(argc == 4 || argc == 5 || argc == 7))
    {
        printf("Error: Wrong number of inputs:%d\n", argc-1);
        exit(EXIT_FAILURE);
    }
    
    params.bp_name  = argv[1];
    
    // strtoul() converts char* to unsigned long. It is included in <stdlib.h>
    if(strcmp(params.bp_name, "bimodal") == 0)              // Bimodal
    {
        if(argc != 4)
        {
            printf("Error: %s wrong number of inputs:%d\n", params.bp_name, argc-1);
            exit(EXIT_FAILURE);
        }
        params.M2       = strtoul(argv[2], NULL, 10);
        trace_file      = argv[3];
        printf("COMMANDn%s %s %lu %s\n", argv[0], params.bp_name, params.M2, trace_file);
    }
    else if(strcmp(params.bp_name, "gshare") == 0)          // Gshare
    {
        if(argc != 5)
        {
            printf("Error: %s wrong number of inputs:%dn", params.bp_name, argc-1);
            exit(EXIT_FAILURE);
        }
        params.M1       = strtoul(argv[2], NULL, 10);
        params.N        = strtoul(argv[3], NULL, 10);
        trace_file      = argv[4];
        printf("COMMANDn%s %s %lu %lu %s\n", argv[0], params.bp_name, params.M1, params.N, trace_file);

    }
    else if(strcmp(params.bp_name, "hybrid") == 0)          // Hybrid
    {
        if(argc != 7)
        {
            printf("Error: %s wrong number of inputs:%d\n", params.bp_name, argc-1);
            exit(EXIT_FAILURE);
        }
        params.K        = strtoul(argv[2], NULL, 10);
        params.M1       = strtoul(argv[3], NULL, 10);
        params.N        = strtoul(argv[4], NULL, 10);
        params.M2       = strtoul(argv[5], NULL, 10);
        trace_file      = argv[6];
        printf("COMMANDn%s %s %lu %lu %lu %lu %s\n", argv[0], params.bp_name, params.K, params.M1, params.N, params.M2, trace_file);

    }
    else
    {
        printf("Error: Wrong branch predictor name:%s\n", params.bp_name);
        exit(EXIT_FAILURE);
    }
    
    // Open trace_file in read mode
    FP = fopen(trace_file, "r");
    if(FP == NULL)
    {
        // Throw error and exit if fopen() failed
        printf("Error: Unable to open file %s\n", trace_file);
        exit(EXIT_FAILURE);
    }
    
    char str[2];
    while(fscanf(FP, "%lx %s", &addr, str) != EOF)
    {
        
        outcome = str[0];
        if (outcome == 't')
            printf("%lx %s\n", addr, "t");           // Print and test if file is read correctly
        else if (outcome == 'n')
            printf("%lx %s\n", addr, "n");          // Print and test if file is read correctly
        /*************************************
            Add branch predictor code here
        **************************************/

        if(strcmp(params.bp_name, "bimodal") == 0){     
            bimodal_func(params.M2, addr, outcome);

        }
        if(strcmp(params.bp_name, "gshare") == 0){
           // gshare_func(m);
        }
        if(strcmp(params.bp_name, "hybrid") == 0){
            //hybrid_func(m);
        }
    }
    return 0;
}

